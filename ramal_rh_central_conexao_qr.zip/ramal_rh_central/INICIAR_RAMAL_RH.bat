@echo off
cd /d "%~dp0"
python servidor_ramal_rh.py
pause
