import http.server, socketserver, json, os, re, socket, urllib.parse, threading, time, base64
from io import BytesIO
try:
    import qrcode
except Exception:
    qrcode = None

PORT=8765
BASE=os.path.dirname(os.path.abspath(__file__))
NUMBERS=[]
STATUS={}
CURRENT=None
LOCK=threading.Lock()
MESSAGE=("Olá, aqui é do setor de Recursos Humanos. Tudo bem? "
         "Estou entrando em contato a respeito de uma oportunidade e gostaria de confirmar algumas informações com você. "
         "Podemos prosseguir com o atendimento?")

HTML='''<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Ramal RH — Central</title><style>
*{box-sizing:border-box}body{margin:0;font-family:Inter,Arial,sans-serif;background:#f5f3f8;color:#201c27}.top{background:linear-gradient(135deg,#5f2b91,#7d45b2);color:white;padding:18px 24px;display:flex;justify-content:space-between;align-items:center}.top h1{margin:0;font-size:22px}.top small{opacity:.85}.wrap{max-width:1180px;margin:22px auto;padding:0 16px}.grid{display:grid;grid-template-columns:1.2fr .8fr;gap:18px}.card{background:white;border:1px solid #e7e1ee;border-radius:18px;padding:20px;box-shadow:0 8px 30px #3d22500d}.stats{display:grid;grid-template-columns:repeat(4,1fr);gap:10px}.stat{padding:15px;border-radius:14px;background:#faf8fc}.stat b{font-size:25px;display:block}.label{font-size:12px;color:#777}.current{text-align:center;padding:28px 10px}.number{font-size:36px;font-weight:800;letter-spacing:1px;margin:10px 0}.badge{display:inline-block;padding:7px 12px;border-radius:99px;background:#eee5f7;color:#652f93;font-weight:700;font-size:13px}.btn{border:0;border-radius:12px;padding:12px 16px;font-weight:700;cursor:pointer;margin:4px}.primary{background:#6b35a0;color:white}.green{background:#18864b;color:white}.red{background:#c93d4b;color:white}.gray{background:#eeeaf1;color:#342d3b}.actions{display:flex;flex-wrap:wrap;justify-content:center}.row{display:flex;gap:10px;align-items:center;margin:10px 0}.row input,.msg{width:100%;padding:12px;border:1px solid #d9d0e1;border-radius:10px}.qr{width:220px;height:220px;border:10px solid white;box-shadow:0 4px 18px #0001;display:block;margin:12px auto}.connected{padding:10px;border-radius:10px;background:#e9f8ef;color:#16713f;font-weight:700;text-align:center}.muted{color:#777;font-size:13px}.full{grid-column:1/-1}.msg{min-height:120px;resize:vertical}.pill{padding:5px 9px;border-radius:8px;font-size:12px;background:#f1edf4}.table{width:100%;border-collapse:collapse}.table th,.table td{padding:10px;border-bottom:1px solid #eee;text-align:left}.table th{font-size:12px;color:#777}.hide{display:none}@media(max-width:850px){.grid{grid-template-columns:1fr}.stats{grid-template-columns:repeat(2,1fr)}.number{font-size:29px}}
</style></head><body><header class="top"><div><h1>Ramal RH — Central de Chamadas</h1><small>Fila telefônica • somente números</small></div><strong>☎ (11) 92488-8822</strong></header><main class="wrap"><div class="grid">
<section class="card"><h2>Atendimento atual</h2><div class="current"><div class="muted">Número selecionado</div><div id="num" class="number">—</div><span id="state" class="badge">Aguardando</span><div class="actions"><button class="btn primary" onclick="next()">▶ Próximo número</button><button class="btn green" onclick="answered()">✓ Atendeu</button><button class="btn red" onclick="notAnswered()">✕ Não atendeu</button></div><div class="muted" id="info">Selecione o próximo número para iniciar.</div></div></section>
<section class="card"><h2>Conectar celular</h2><div id="conn" class="connected">Aguardando conexão do celular</div><img id="qr" class="qr" src="/qr.png" alt="QR Code de conexão"><p class="muted" style="text-align:center">Escaneie este QR com o celular. PC e celular precisam estar na mesma rede Wi‑Fi.</p><div class="row"><button class="btn gray" onclick="location.reload()">↻ Atualizar QR</button><button class="btn primary" onclick="sendCurrent()">📱 Enviar número ao celular</button></div></section>
<section class="card full"><h2>Mensagem de atendimento do robô</h2><textarea id="message" class="msg">Olá, aqui é do setor de Recursos Humanos. Tudo bem? Estou entrando em contato a respeito de uma oportunidade e gostaria de confirmar algumas informações com você. Podemos prosseguir com o atendimento?</textarea><div class="actions"><button class="btn primary" onclick="speak()">▶ Reproduzir mensagem</button><button class="btn gray" onclick="speechSynthesis.cancel()">■ Parar</button><button class="btn green" onclick="saveMsg()">Salvar mensagem</button></div><p class="muted">A mensagem é reproduzida no computador quando você confirma que a ligação foi atendida. Você pode editar o texto quando quiser.</p></section>
<section class="card full"><div class="stats"><div class="stat"><span class="label">Total</span><b id="total">0</b></div><div class="stat"><span class="label">Pendentes</span><b id="pending">0</b></div><div class="stat"><span class="label">Atendidos</span><b id="answered">0</b></div><div class="stat"><span class="label">Não atendeu</span><b id="missed">0</b></div></div><div class="row" style="margin-top:16px"><input type="file" id="file" accept=".txt"><button class="btn primary" onclick="upload()">Carregar TXT</button><button class="btn red" onclick="resetAll()">Zerar status</button></div><div class="muted">O TXT deve ter um telefone por linha. Nomes, e-mails e outros textos são ignorados.</div></section>
<section class="card full"><h2>Fila</h2><table class="table"><thead><tr><th>#</th><th>Número</th><th>Status</th></tr></thead><tbody id="tbody"></tbody></table></section></div></main><script>
let last='';
async function api(url,opt){let r=await fetch(url,opt);return r.json()}
function fmt(n){n=n||'';return n.length===11?'('+n.slice(0,2)+') '+n.slice(2,7)+'-'+n.slice(7):n}
async function refresh(){let s=await api('/api/state');document.getElementById('num').textContent=s.current?fmt(s.current):'—';document.getElementById('state').textContent=s.current_status||'Aguardando';document.getElementById('total').textContent=s.total;document.getElementById('pending').textContent=s.pending;document.getElementById('answered').textContent=s.answered;document.getElementById('missed').textContent=s.missed;document.getElementById('conn').textContent=s.mobile?'✓ Celular conectado':'Aguardando conexão do celular';document.getElementById('info').textContent=s.current?'Número enviado para o celular. O funcionário deve tocar em "Ligar".':'Selecione o próximo número para iniciar.';document.getElementById('tbody').innerHTML=s.rows.map((x,i)=>`<tr><td>${i+1}</td><td><b>${fmt(x.number)}</b></td><td><span class="pill">${x.status}</span></td></tr>`).join('')}
async function next(){await api('/api/next',{method:'POST'});await refresh();await sendCurrent()}
async function sendCurrent(){let s=await api('/api/state');if(!s.current)return;await api('/api/send',{method:'POST'});refresh()}
async function answered(){await api('/api/status',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({status:'Atendeu'})});await refresh();speak()}
async function notAnswered(){await api('/api/status',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({status:'Não atendeu'})});await refresh()}
function speak(){speechSynthesis.cancel();let u=new SpeechSynthesisUtterance(document.getElementById('message').value);u.lang='pt-BR';u.rate=.96;u.pitch=1;speechSynthesis.speak(u)}
function saveMsg(){localStorage.setItem('rhmsg',document.getElementById('message').value);alert('Mensagem salva neste computador.')}async function upload(){let f=document.getElementById('file').files[0];if(!f)return alert('Selecione o TXT.');let fd=new FormData();fd.append('file',f);let r=await fetch('/api/upload',{method:'POST',body:fd});let j=await r.json();if(!j.ok)return alert(j.error);alert(j.count+' números carregados.');refresh()}
async function resetAll(){if(confirm('Zerar todos os status?')){await api('/api/reset',{method:'POST'});refresh()}}
window.onload=()=>{let m=localStorage.getItem('rhmsg');if(m)document.getElementById('message').value=m;refresh();setInterval(refresh,1500)};
</script></body></html>'''

MOBILE='''<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="theme-color" content="#6b35a0"><title>Ramal RH — Celular</title><style>body{margin:0;background:#f5f3f8;font-family:Arial,sans-serif;color:#211b28}.top{background:#6b35a0;color:white;padding:20px;text-align:center}.wrap{padding:18px}.card{background:white;border-radius:18px;padding:22px;box-shadow:0 6px 25px #0001}.number{font-size:34px;font-weight:800;text-align:center;margin:30px 0}.status{text-align:center;color:#6b35a0;font-weight:700}.btn{width:100%;padding:18px;border:0;border-radius:14px;font-size:19px;font-weight:800;margin-top:12px}.call{background:#198754;color:white}.done{background:#6b35a0;color:white}.muted{text-align:center;color:#777;font-size:13px}.ok{background:#e8f7ee;color:#187341;padding:10px;border-radius:10px;text-align:center;font-weight:bold}</style></head><body><div class="top"><b>Ramal RH</b><div>Celular do funcionário</div></div><main class="wrap"><div class="card"><div id="connection" class="ok">✓ Celular conectado</div><div class="status" id="status">Aguardando próximo número</div><div class="number" id="num">—</div><button id="call" class="btn call" onclick="call()" disabled>☎ LIGAR PARA O NÚMERO</button><button class="btn done" onclick="ready()">✓ Estou pronto para o próximo</button><p class="muted">O número enviado pelo computador aparecerá aqui. Toque em LIGAR e faça a chamada normalmente.</p></div></main><script>let current='';async function st(){let s=await (await fetch('/api/state?mobile=1')).json();document.getElementById('num').textContent=s.current?s.current:'—';document.getElementById('status').textContent=s.current_status||'Aguardando próximo número';document.getElementById('call').disabled=!s.current;current=s.current||''}function call(){if(current)location.href='tel:+55'+current}async function ready(){await fetch('/api/mobile-ready',{method:'POST'});st()}st();setInterval(st,1000)</script></body></html>'''

class Handler(http.server.BaseHTTPRequestHandler):
    def log_message(self,*a): pass
    def send_json(self,obj,code=200):
        b=json.dumps(obj,ensure_ascii=False).encode();self.send_response(code);self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Content-Length',str(len(b)));self.end_headers();self.wfile.write(b)
    def do_GET(self):
        global CURRENT
        p=urllib.parse.urlparse(self.path).path
        if p=='/': return self.page(HTML)
        if p=='/mobile': return self.page(MOBILE)
        if p=='/api/state':
            with LOCK:
                counts={'Pendente':0,'Atendeu':0,'Não atendeu':0}
                for n in NUMBERS: counts[STATUS.get(n,'Pendente')]=counts.get(STATUS.get(n,'Pendente'),0)+1
                rows=[{'number':n,'status':STATUS.get(n,'Pendente')} for n in NUMBERS[:100]]
                curstatus=STATUS.get(CURRENT,'Em ligação') if CURRENT else None
                self.send_json({'total':len(NUMBERS),'pending':counts.get('Pendente',0),'answered':counts.get('Atendeu',0),'missed':counts.get('Não atendeu',0),'current':CURRENT,'current_status':curstatus,'mobile':True,'rows':rows})
            return
        if p=='/qr.png': return self.qr()
        self.send_response(404);self.end_headers()
    def page(self,s):
        b=s.encode();self.send_response(200);self.send_header('Content-Type','text/html; charset=utf-8');self.send_header('Content-Length',str(len(b)));self.end_headers();self.wfile.write(b)
    def qr(self):
        url='http://'+local_ip()+':'+str(PORT)+'/mobile'
        if not qrcode:
            self.send_response(500);self.end_headers();return
        im=qrcode.make(url);out=BytesIO();im.save(out,format='PNG');b=out.getvalue();self.send_response(200);self.send_header('Content-Type','image/png');self.send_header('Content-Length',str(len(b)));self.end_headers();self.wfile.write(b)
    def do_POST(self):
        global CURRENT
        p=urllib.parse.urlparse(self.path).path
        if p=='/api/next':
            with LOCK:
                for n in NUMBERS:
                    if STATUS.get(n,'Pendente')=='Pendente': CURRENT=n;STATUS[n]='Em ligação';break
            return self.send_json({'ok':True,'current':CURRENT})
        if p=='/api/send': return self.send_json({'ok':True,'current':CURRENT})
        if p=='/api/status':
            ln=int(self.headers.get('Content-Length','0'));d=json.loads(self.rfile.read(ln) or '{}');st=d.get('status')
            with LOCK:
                if CURRENT and st in ('Atendeu','Não atendeu'): STATUS[CURRENT]=st
            return self.send_json({'ok':True})
        if p=='/api/reset':
            with LOCK:
                STATUS.clear();CURRENT=None
            return self.send_json({'ok':True})
        if p=='/api/mobile-ready': return self.send_json({'ok':True})
        if p=='/api/upload':
            ln=int(self.headers.get('Content-Length','0'));data=self.rfile.read(ln);m=re.search(b'\r?\n\r?\n',data); 
            if not m:return self.send_json({'ok':False,'error':'Arquivo inválido'},400)
            body=data[m.end():]; body=body.rsplit(b'\r\n--',1)[0]
            text=body.decode('utf-8','ignore')
            nums=[]
            for line in text.splitlines():
                digits=re.sub(r'\D','',line)
                if digits.startswith('55') and len(digits) in (12,13): digits=digits[2:]
                if len(digits) in (10,11): nums.append(digits)
            seen=set();nums=[x for x in nums if not (x in seen or seen.add(x))]
            with LOCK:
                NUMBERS[:]=nums;STATUS.clear();CURRENT=None
            return self.send_json({'ok':True,'count':len(nums)})
        self.send_response(404);self.end_headers()

def local_ip():
    s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
    try:s.connect(('8.8.8.8',80));return s.getsockname()[0]
    except:return '127.0.0.1'
    finally:s.close()

if __name__=='__main__':
    # optional initial TXT beside this script
    for fn in ['dd (1).txt','numeros.txt','lista.txt']:
        path=os.path.join(BASE,fn)
        if os.path.exists(path):
            with open(path,'r',encoding='utf-8',errors='ignore') as f:
                seen=set()
                for line in f:
                    d=re.sub(r'\D','',line)
                    if d.startswith('55') and len(d) in (12,13):d=d[2:]
                    if len(d) in (10,11) and d not in seen:NUMBERS.append(d);seen.add(d)
            break
    print('\n=== RAMAL RH — CENTRAL DE CHAMADAS ===')
    print('PC:      http://localhost:%s/'%PORT)
    print('CELULAR: http://%s:%s/mobile'%(local_ip(),PORT))
    print('Abra o PC pelo endereço acima e escaneie o QR.')
    print('PC e celular precisam estar na mesma Wi-Fi.\n')
    with socketserver.ThreadingTCPServer(('0.0.0.0',PORT),Handler) as srv:srv.serve_forever()
